import java.awt.Image;

import javax.swing.ImageIcon;

public class Obstacle {
	private float x;
	private float y;
	private int w;
	private int h;
	private Image image;
	
	public Obstacle(float x, float y) {
		ImageIcon ii = new ImageIcon(new ImageIcon("obstacle1.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		image = ii.getImage(); 

		w = image.getWidth(null);
		h = image.getHeight(null);
		this.x=x;
		this.y=y;
	}
	
	public void setX(float x) {
		this.x=x;
	}
	
	public void setY(float y) {
		this.y=y;
	}
	
	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public int getWidth() {

		return w;
	}

	public int getHeight() {

		return h;
	}    

	public Image getImage() {

		return image;
	}
}
