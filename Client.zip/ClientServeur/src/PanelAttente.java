import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class PanelAttente extends JPanel {
	private static final long serialVersionUID = 1L;
	
	public PanelAttente() {
		setBackground(Color.black);
		setFocusable(true);
		repaint();
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		dessineAttente(g);
	}

	private void dessineAttente(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;

		this.setBackground(Color.black);

		g2d.setColor(Color.WHITE);
		g2d.setFont(new Font("Arial", Font.PLAIN, 30)); 
		g2d.drawString("En attente de joueurs...", this.getWidth()/2-190, this.getHeight()/2-8);
	}
}
