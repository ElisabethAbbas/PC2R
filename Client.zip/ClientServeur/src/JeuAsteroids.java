import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.util.HashMap;
import java.util.Vector;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.JFrame;

public class JeuAsteroids extends Thread {
	private float x, y;
	private String phase;
	private HashMap<String, Coordonnee> vcoordonnees;
	private Coordonnee objectif;
	Vector<Coordonnee> obstacles;
	private LecteurCommandes lecteur;
	private PanelJeu panelJeu;
	private PanelAttente panelAttente;
	JFrame frame;
	static final Lock lockPanelJeu = new ReentrantLock();
	static final Condition panelJeuNonNull  = lockPanelJeu.newCondition(); 

	public JeuAsteroids(String s, LecteurCommandes l, String ph, HashMap<String, Integer> sc, float x, float y, Vector<Coordonnee> obs) {
		super(s);
		this.x=x;
		this.y=y;
		this.phase=ph;
		this.lecteur=l;
		panelJeu=new PanelJeu(x, y, obs);
		panelAttente=new PanelAttente();
	}
	
	WindowListener l = new WindowAdapter() {
		public void windowClosing(WindowEvent e){
			try {
				lecteur.commandeExit();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	};
	
	public void setVCoordonnees(HashMap<String, Coordonnee> c) {
		vcoordonnees=c;
		if (panelJeu!=null)
			panelJeu.updateVaisseaux(vcoordonnees);
	}
	
	public void setObjectif(Coordonnee obj) {
		objectif=obj;
		panelJeu.setObjectif(obj);
	}
	
	public void setObstacles(Vector<Coordonnee> obs) {
		panelJeu.setObstacles(obs);
	}
	
	public Vaisseau getVaisseau() {
		lockPanelJeu.lock();
		while(panelJeu==null) {
			try {
				panelJeuNonNull.await();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		lockPanelJeu.unlock();
		
		return panelJeu.getVaisseau();
	}

	public float getXVaisseau() {
		return panelJeu.getXVaisseau();
	}

	public float getYVaisseau() {
		return panelJeu.getYVaisseau();
	}
	
	public float getAVaisseau() {
		return panelJeu.getAVaisseau();
	}
	
	public int getTVaisseau() {
		return panelJeu.getTVaisseau();
	}

	public void setPhase(String s) {
		phase = s;
	}

	public void changerPhase(){
		System.out.println("changer phase");
		if (phase.equals("attente")) {
			if(panelJeu!=null) {
				frame.remove(panelJeu);
			}
			frame.add(panelAttente);
		}
		else {
			if(panelAttente!=null) {
				frame.remove(panelAttente);
			}
			lockPanelJeu.lock();
			panelJeuNonNull.signal(); // pour que panelJeu ne soit pas vide
			lockPanelJeu.unlock();
			frame.add(panelJeu);
			panelJeu.grabFocus();
		}
		frame.addWindowListener(l);
		frame.validate();
		frame.repaint();
	}

	@Override
	public void run() {
		// on crée une fenêtre 
		frame = new JFrame("Asteroids");
		// la fenêtre doit se fermer quand on clique sur la croix rouge
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		changerPhase();

		frame.getContentPane().setBackground(Color.black);
		frame.setSize(600,600);
		frame.setResizable(false);
		//frame.pack();
		// on centre la fenêtre
		frame.setLocationRelativeTo(null);
		// on rend la fenêtre visible
		frame.setFocusable(true);
		frame.setVisible(true);
		EventQueue.invokeLater(() -> {
			frame.setVisible(true);
		});
	}

	public void setAVaisseau(float f) {
		panelJeu.setAVaisseau(f);
	}
	
	public void setTVaisseau(int i) {
		panelJeu.setTVaisseau(i);
	}
}
