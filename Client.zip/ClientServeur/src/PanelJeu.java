import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Vector;

public class PanelJeu extends JPanel /*implements ActionListener*/ {
	private static final long serialVersionUID = 1L;

	private Vaisseau vaisseau;
	private HashMap<String, VaisseauI> vaisseaux = new HashMap<String, VaisseauI>();
	private Objectif objectif;
	private Vector<Obstacle> obstacles;

	public PanelJeu(float x, float y, Vector<Coordonnee> obs) {
		addKeyListener(new TAdapter());
		setBackground(Color.black);
		setFocusable(true);

		objectif= new Objectif(x, y);
		obstacles= new Vector<Obstacle>();
		obstacles.add(new Obstacle(obs.get(0).x, obs.get(0).y));
		obstacles.add(new Obstacle(obs.get(1).x, obs.get(1).y));
		obstacles.add(new Obstacle(obs.get(2).x, obs.get(2).y));
	}
	
	public Vaisseau getVaisseau() {
		return vaisseau;
	}

	// mettre mutex avec affichage !! dire dans rapport
	public void updateVaisseaux(HashMap<String, Coordonnee> coordonnees){
		synchronized(vaisseaux) {
			for(String pseudo : coordonnees.keySet()) {
				Coordonnee c = coordonnees.get(pseudo);
				if(pseudo.equals(Client.pseudo)) {
					LecteurCommandes.lockVaisseau.lock();
					if(vaisseau==null)
						vaisseau=new Vaisseau(c.x, c.y);
					else {
						vaisseau.setX(c.x);
						vaisseau.setY(c.y);
						vaisseau.setTheta(c.t);
					}
					LecteurCommandes.vaisseauNonNull.signal();
					LecteurCommandes.lockVaisseau.unlock();
				}
				if(vaisseaux.containsKey(pseudo)) {
					vaisseaux.get(pseudo).setX(c.x);
					vaisseaux.get(pseudo).setY(c.y);
				}
				else
					vaisseaux.put(pseudo, new VaisseauEnnemi(c.x, c.y));
			}
			
			repaint();
			Toolkit.getDefaultToolkit().sync();
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		synchronized(vaisseaux) {
			super.paintComponent(g);

			this.setBackground(Color.black);

			g.drawImage(objectif.getImage(), (int)objectif.getX(), 
					(int)objectif.getY(), this);
			
			for(Obstacle o : obstacles) {
				g.drawImage(o.getImage(), (int)o.getX(), 
						(int)o.getY(), this);
			}
		
			dessineVaisseaux(g);
		}
			
	}

	public float getXVaisseau() {
		return vaisseau.getX();
	}

	public float getYVaisseau() {
		return vaisseau.getY();
	}
	
	public float getAVaisseau() {
		return vaisseau.getDthetha();
	}
	
	public int getTVaisseau() {
		return vaisseau.getFrappes();
	}

	private void dessineVaisseaux(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;

		double alpha=0, x=0, y=0;
		for(String pseudo : vaisseaux.keySet()) {
			VaisseauI v = vaisseaux.get(pseudo);
			if(Client.pseudo.equals(pseudo)) {
				g2d.rotate(alpha=(vaisseau.getTheta()*Math.PI/180.0), x=v.getX()+(v.getWidth()/2), y=v.getY()+(v.getHeight()/2));
				g2d.drawImage(vaisseau.getImage(), (int)v.getX(), 
						(int)v.getY(), this);
			}
			else {
				if(alpha!=0) {
					g2d.rotate(-alpha, x, y);
				}
				g2d.drawImage(v.getImage(), (int)v.getX(), 
						(int)v.getY(), this);
				if(alpha!=0)
					alpha=0;
			}
		}
	}

	private class TAdapter extends KeyAdapter {
		@Override
		public void keyPressed(KeyEvent e) {
			if(vaisseau!=null)
				vaisseau.keyPressed(e);
		}        
	}

	public void setAVaisseau(float f) {
		vaisseau.setDTheta(f);		
	}
	
	public void setTVaisseau(int i) {
		vaisseau.setFrappes(i);
	}
	
	public void setObjectif(Coordonnee obj) {
		objectif= new Objectif(obj.x, obj.y);
	}

	public void setObstacles(Vector<Coordonnee> obs) {
		obstacles.set(0, new Obstacle(obs.get(0).x, obs.get(0).y));
		obstacles.set(1, new Obstacle(obs.get(1).x, obs.get(1).y));
		obstacles.set(2, new Obstacle(obs.get(2).x, obs.get(2).y));
	}
}
