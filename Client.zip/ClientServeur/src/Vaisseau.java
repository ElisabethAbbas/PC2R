import java.awt.Image;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

public class Vaisseau implements VaisseauI{
	private float x;
	private float y;
	private float vx=0;
	private float vy=0;
	private float theta;
	private float dtheta;
	private int w;
	private int h;
	private Image image;
	private final float turnit=15;
	//private final float thrustit=0.01f;
	//private int fx=600,fy=600;
	private int frappes;
	
	public Vaisseau(float x, float y) {
		ImageIcon ii = new ImageIcon(new ImageIcon("vaisseau.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		image = ii.getImage(); 

		w = image.getWidth(null);
		h = image.getHeight(null);
		this.x=x;
		this.y=y;
		
		theta = 0;
		dtheta=0;
		frappes=0;
	}
	
	public void setX(float s) {
		x=s;
	}
	
	public void setY(float s) {
		y=s;
	}
	
	public void setTheta(float s) {
		theta=s;
	}
	
	public int getFrappes() {
		return frappes;
	}
	
	public float getDthetha() {
		return dtheta;
	}
	
	public float getX() {

		return x;
	}

	public float getY() {

		return y;
	}
	
	public float getTheta() {

		return theta;
	}
	
	public void setDTheta(float f) {
		dtheta=f;
	}
	
	public void setFrappes(int i) {
		frappes=i;
	}

	public int getWidth() {

		return w;
	}

	public int getHeight() {

		return h;
	}    

	public Image getImage() {

		return image;
	}

	public void keyPressed(KeyEvent e) {

		int key = e.getKeyCode();

		if (key == KeyEvent.VK_LEFT) {
			clock();
		}

		if (key == KeyEvent.VK_RIGHT) {
			anticlock();
		}

		if (key == KeyEvent.VK_UP) {
			thrust();
		}
	}
		
	public void clock() {
		dtheta-=turnit;
	}
	
	public void anticlock() {
		dtheta+=turnit;
	}
	
	public void thrust() {
		frappes+=1;
		/*vx+=thrustit*Math.cos(theta*Math.PI/180.0);
		vy+=thrustit*Math.sin(theta*Math.PI/180.0);*/
	}

	public void move() {
		/*x = x + vx; 
		if(x>w)
			x=x-fx;
		if(x<0)
			x=fx+x;
		y = y + vy;
		if(y>h)
			y=y-fy;
		if(y<0)
			y=fy+y;*/
	}
}
