import java.awt.Image;

// expliquer dans rapport pourquoi on a fait une interface (pour stocker différents types de vaisseaus dans la hashtable, le mien (dirigeable) et ceux ennemis).
public interface VaisseauI {
		public float getX();
		public float getY();
		public void setX(float x);
		public void setY(float y);
		public int getWidth();
		public int getHeight();
		public Image getImage();
}
