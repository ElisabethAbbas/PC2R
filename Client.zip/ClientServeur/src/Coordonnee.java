
public class Coordonnee {
	float x;
	float y;
	float t;
	
	public Coordonnee(float x2, float y2) {
		x=x2;
		y=y2;
		t=0;
	}
	
	public Coordonnee(float x2, float y2, float t2) {
		x=x2;
		y=y2;
		t=t2;
	}
}
