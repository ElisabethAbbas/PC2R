import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Vector;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LecteurCommandes extends Thread{

	BufferedReader is;
	BufferedWriter os;
	float refresh_tickrate = 30.0f;
	String pseudo;
	static final Lock lockVaisseau = new ReentrantLock();// mettre dans rapport : sert à poser une condition variable si vaisseau est null en attendant le update alors qu'on souhaite envoyer les coordonnees au serveur.
	static final Condition vaisseauNonNull  = lockVaisseau.newCondition(); 
	static final Lock lockAsteroids = new ReentrantLock();// mettre dans rapport : sert à poser une condition variable si asteroids est null
	static final Condition asteroidsNonNull  = lockAsteroids.newCondition(); 


	JeuAsteroids asteroids;

	public LecteurCommandes (String s, BufferedReader is, BufferedWriter os, String pseudo) {
		super(s);
		this.is = is;
		this.os=os;
		this.pseudo=pseudo;
	}

	public void commandeExit() throws IOException {
		try {
		os.write("EXIT/"+pseudo+"/\n");
		os.flush();
		System.exit(0);
		}
		catch(IOException e) {
			System.exit(0);
		}
	}

	public HashMap<String, Integer> scoresToScoresTable(String scores) {
		HashMap<String, Integer> scorestable= new HashMap<String, Integer>();
		if(scores.equals(""))
			return scorestable;
		String [] scores_ = scores.split("\\|"); // mettre dans rapport : split ne marche pas avec | car signification dans une regex
		//http://www.programming-free.com/2015/09/java-string-spilit-with-pipe-character.html
		String [] tmp2;
		for(String s : scores_) {
			tmp2 = s.split(":");
			scorestable.put(tmp2[0], Integer.valueOf(tmp2[1]));
		}
		return scorestable;
	}

	public String coordonneeToCoord() {
		return "X"+asteroids.getXVaisseau()+"Y"+asteroids.getYVaisseau();
	}
	
	public String coordonneeToVCoord() {
		return "A"+asteroids.getAVaisseau()+"T"+asteroids.getTVaisseau();
	}

	public HashMap<String, Coordonnee> coordsToCoordonnees(String s) {
		HashMap<String, Coordonnee> h = new HashMap<String, Coordonnee>();

		String[] r = s.split("\\|");
		for(String a : r) {
			String[] b = a.split(":");
			h.put(b[0], CoordToCoordonnee(b[1]));
		}

		return h;
	}
	
	public HashMap<String, Coordonnee> coordsToVCoordonnees(String s) {
		HashMap<String, Coordonnee> h = new HashMap<String, Coordonnee>();

		String[] r = s.split("\\|");
		for(String a : r) {
			String[] b = a.split(":");
			h.put(b[0], CoordToVCoordonnee(b[1]));
		}

		return h;
	}

	public Coordonnee CoordToVCoordonnee(String s) {
		String coord[] = s.split("VX");
		String sansvx0 = coord[0];
		String sansvx1 = coord[1];
		coord = sansvx0.split("X");
		String sansx = coord[1];
		coord = sansx.split("Y");
		
		float x = Float.valueOf(coord[0]);
		float y = Float.valueOf(coord[1]);
		
		coord = sansvx1.split("VY");
		float vx = Float.valueOf(coord[0]);
		String sansvy = coord[1];
		coord = sansvy.split("T");
		float vy = Float.valueOf(coord[0]);
		float t = Float.valueOf(coord[1]);
		return new Coordonnee(x,y,t);
	}
	
	public Vector<Coordonnee> ocoordsToObstacles(String s) {
		String coord[] = s.split("\\|");
		String o0 = coord[0];
		String o1 = coord[1];
		String o2 = coord[2];
		
		Vector<Coordonnee> obstacles = new Vector<Coordonnee>();
		
		obstacles.add(CoordToCoordonnee(o0));
		obstacles.add(CoordToCoordonnee(o1));
		obstacles.add(CoordToCoordonnee(o2));
		return obstacles;
	}

	public Coordonnee CoordToCoordonnee(String s) {
		String coord[] = s.split("X")[1].split("Y");
		float x = Float.valueOf(coord[0]);
		float y = Float.valueOf(coord[1]);
		return new Coordonnee(x,y);
	}

	@Override
	public void run() {
		String responseLine;
		String cmd[];
		try {
			while ((responseLine = is.readLine()) != null) { // avant attente active, on a enlevé ça, mettre ds rapport
				// bloquant -> pas d'attente active dans le thread, thread fait exprès pour pouvoir faire autre chose à côté, le dire ds rapport
				cmd=responseLine.split("/");
				if(cmd[0].equals("WELCOME")) {
					System.out.println("Validation de la connexion... "+cmd[1]+" "+cmd[2]+" "+cmd[3]+" "+cmd[4]);
					System.out.flush();
					String phase = cmd[1];
					HashMap<String, Integer> sct = scoresToScoresTable(cmd[2]);
					String coord[] = cmd[3].split("X")[1].split("Y");
					float x = Float.valueOf(coord[0]);
					float y = Float.valueOf(coord[1]);
					Vector<Coordonnee> obstacles = ocoordsToObstacles(cmd[4]);
					lockAsteroids.lock();
					asteroids = new JeuAsteroids("Asteroids ", this, phase, sct, x, y, obstacles);
					asteroidsNonNull.signal();
					asteroids.start();
					lockAsteroids.unlock();
				}
				if(cmd[0].equals("DENIED")) {
					System.out.println("Connexion refusée.");
					System.out.flush();
					break;
				}
				if(cmd[0].equals("NEWPLAYER")) {
					System.out.println("Connexion de "+cmd[1]);
					System.out.flush();
				}
				if(cmd[0].equals("PLAYERLEFT")) {
					System.out.println("Deconnexion de "+cmd[1]);
					System.out.flush();
				}
				if(cmd[0].equals("TICK")) {
					//mettre synchronized
					asteroids.setVCoordonnees(coordsToVCoordonnees(cmd[1]));
					try {
						Thread.sleep((long) (1.0/refresh_tickrate));
					} catch (InterruptedException e2) {
						e2.printStackTrace();
					}
					// expliquer dans rapport ce lock
					lockAsteroids.lock();
					while(asteroids==null) {
						try {
							asteroidsNonNull.await();
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
					}
					lockAsteroids.unlock();
					lockVaisseau.lock();
					while(asteroids.getVaisseau()==null)
						try {
							vaisseauNonNull.await();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					lockVaisseau.unlock();
					//mettre mutex
					os.write("NEWCOM/"+coordonneeToVCoord()+"/\n");
					asteroids.setAVaisseau(0.0f);
					asteroids.setTVaisseau(0);
					os.flush();
				}
				if(cmd[0].equals("SESSION")) {
					System.out.println("Début de la session.");
					asteroids.setPhase("jeu");
					asteroids.setVCoordonnees(coordsToCoordonnees(cmd[1]));
					asteroids.setObjectif(CoordToCoordonnee(cmd[2]));
					asteroids.setObstacles(ocoordsToObstacles(cmd[3]));
					asteroids.changerPhase();
				}
				if(cmd[0].equals("WINNER")) {
					System.out.println("Un gagnant! Voici les scores :");
					System.out.println(cmd[1]);
					asteroids.setPhase("attente");
					asteroids.changerPhase();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
