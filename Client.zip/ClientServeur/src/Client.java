import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {

	static String pseudo;
	public static void main(String[] args) {

		if(args.length!=2) {
			System.out.println("usage : command serveur port");
			System.exit(-1);
		}
		// Server Host
		final String serverHost = args[0];

		Socket socketOfClient = null;
		BufferedWriter os = null;
		BufferedReader is = null;

		try {

			// Send a request to connect to the server is listening
			// on machine 'localhost' port 9999.
			socketOfClient = new Socket(serverHost, Integer.valueOf(args[1]));

			// Create output stream at the client (to send data to the server)
			os = new BufferedWriter(new OutputStreamWriter(socketOfClient.getOutputStream()));


			// Input stream at Client (Receive data from the server).
			is = new BufferedReader(new InputStreamReader(socketOfClient.getInputStream()));

		} catch (UnknownHostException e) {
			System.err.println("Don't know about host " + serverHost);
			return;
		} catch (IOException e) {
			System.err.println("Couldn't get I/O for the connection to " + serverHost);
			return;
		}

		try {
			// choisir pseudo?
			System.out.println("Choisissez votre pseudo : ");
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			pseudo = sc.nextLine();
			
			// Write data to the output stream of the Client Socket.
			os.write("CONNECT/"+pseudo+"/\n");
			// Flush data.
			os.flush();
			
			
			
           //String num = is.readLine();
			
			// Read data sent from the server.
			// By reading the input stream of the Client Socket.
			
			LecteurCommandes l = new LecteurCommandes(pseudo, is, os, pseudo);
			l.start();
			
			/*while(true) {
				Scanner sc2 = new Scanner(System.in);
				String commande = sc2.nextLine();
				if(commande.equals("")) {
					os.write("EXIT/"+pseudo+"/\n");
					os.flush();
					break;
				}
			}*/
			
			try {
				l.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// déconnexion, voir comment la provoquer
			/*os.write("EXIT/"+pseudo+"/");
           os.newLine();
           os.flush();*/

			// relais brisé sûrement car ça arrive au close trop tôt

			os.close();
			is.close();
			socketOfClient.close();
		} catch (UnknownHostException e) {
			System.err.println("Trying to connect to unknown host: " + e);
		} catch (IOException e) {
			System.err.println("IOException:  " + e);
		}
	}

}